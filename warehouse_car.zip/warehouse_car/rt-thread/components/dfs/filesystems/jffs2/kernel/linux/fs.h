#ifndef __LINUX_FS_H__
#define __LINUX_FS_H__

#include <linux/stat.h>

#endif /* __LINUX_FS_H__ */
